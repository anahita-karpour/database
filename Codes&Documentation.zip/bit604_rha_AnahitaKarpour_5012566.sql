-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: bit604_rha
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apartment`
--

DROP TABLE IF EXISTS `apartment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apartment` (
  `AptNum` int NOT NULL,
  `BuildID` varchar(5) NOT NULL,
  `AptType` varchar(2) DEFAULT NULL,
  `Bedrooms` int DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`AptNum`,`BuildID`),
  KEY `FK_BuildID` (`BuildID`),
  CONSTRAINT `FK_BuildID` FOREIGN KEY (`BuildID`) REFERENCES `apartment_building` (`BuildID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartment`
--

LOCK TABLES `apartment` WRITE;
/*!40000 ALTER TABLE `apartment` DISABLE KEYS */;
INSERT INTO `apartment` VALUES (101,'B002','S',1,110.00),(101,'B009','S',2,160.00),(102,'B004','S',1,85.00),(103,'B001','S',1,90.00),(103,'B009','S',1,120.00),(104,'B001','GA',2,175.00),(104,'B002','S',2,155.00),(105,'B005','S',2,165.00),(105,'B007','S',1,110.00),(108,'B003','S',1,90.00),(108,'B005','S',1,95.00),(109,'B004','GA',2,150.00),(111,'B008','S',2,155.00),(202,'B004','S',2,175.00),(204,'B004','S',1,100.00),(205,'B004','GA',1,105.00),(205,'B006','S',2,150.00),(208,'B002','S',2,140.00),(209,'B001','S',2,135.00),(211,'B002','S',2,140.00),(301,'B004','PH',2,190.00),(303,'B004','S',3,255.00),(303,'B008','PH',3,320.00),(304,'B003','PH',2,185.00),(307,'B002','S',3,280.00),(307,'B008','PH',3,300.00);
/*!40000 ALTER TABLE `apartment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apartment_building`
--

DROP TABLE IF EXISTS `apartment_building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apartment_building` (
  `BuildID` varchar(5) NOT NULL,
  `BuildName` varchar(25) DEFAULT NULL,
  `Location` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`BuildID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartment_building`
--

LOCK TABLES `apartment_building` WRITE;
/*!40000 ALTER TABLE `apartment_building` DISABLE KEYS */;
INSERT INTO `apartment_building` VALUES ('B001','Paradise Found','Rotorua'),('B002','Serenity Place','Queenstown'),('B003','Sunshine Oasis','Nelson'),('B004','Beach View','Auckland'),('B005','Heavens Gate','Dunedin'),('B006','Lakeview Bliss','Taupo'),('B007','Sunrise Resort','Christchurch'),('B008','Harmony','Tauranga'),('B009','Rising Star','Wellington');
/*!40000 ALTER TABLE `apartment_building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `ReservationID` varchar(5) NOT NULL,
  `BuildID` varchar(5) DEFAULT NULL,
  `VisitorID` varchar(5) DEFAULT NULL,
  `DateFrom` date DEFAULT NULL,
  `DateTo` date DEFAULT NULL,
  `AptNum` int DEFAULT NULL,
  PRIMARY KEY (`ReservationID`),
  KEY `FK_BuildID_Resev` (`BuildID`),
  KEY `FK_VisitorID` (`VisitorID`),
  KEY `FK_AptNum` (`AptNum`),
  CONSTRAINT `FK_AptNum` FOREIGN KEY (`AptNum`) REFERENCES `apartment` (`AptNum`) ON UPDATE CASCADE,
  CONSTRAINT `FK_BuildID_Resev` FOREIGN KEY (`BuildID`) REFERENCES `apartment_building` (`BuildID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_VisitorID` FOREIGN KEY (`VisitorID`) REFERENCES `visitor` (`VisitorID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES ('R001','B005','V002','2020-10-01','2020-10-06',108),('R002','B004','V001','2020-09-25','2020-10-02',202),('R003','B004','V004','2020-10-04','2020-10-12',301),('R004','B002','V007','2020-09-17','2020-09-20',307),('R005','B001','V003','2020-09-30','2020-10-04',104),('R006','B006','V005','2020-10-10','2020-10-18',205),('R007','B002','V008','2020-10-10','2020-10-20',104),('R008','B004','V006','2020-10-21','2020-11-01',205),('R009','B001','V010','2020-10-23','2020-10-29',209),('R010','B003','V009','2020-10-24','2020-11-03',108),('R011','B009','V003','2020-10-29','2020-11-05',101),('R012','B009','V001','2020-11-06','2020-11-13',103),('R013','B004','V007','2020-10-03','2020-10-10',303),('R014','B007','V011','2020-10-31','2020-11-06',105),('R015','B008','V012','2020-11-08','2020-11-15',307);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor`
--

DROP TABLE IF EXISTS `visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitor` (
  `VisitorID` varchar(5) NOT NULL,
  `VisitorName` varchar(25) DEFAULT NULL,
  `VisitorAddress` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`VisitorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor`
--

LOCK TABLES `visitor` WRITE;
/*!40000 ALTER TABLE `visitor` DISABLE KEYS */;
INSERT INTO `visitor` VALUES ('V001','Jane Bolcotte','3 Garden St., Greenville'),('V002','Peter Bell','15 Long St., Blackston'),('V003','Bao Wang','88 Wide St., Bankston'),('V004','Evan Taylor','23 High St., Cleanville'),('V005','Manaia Ariki','75 Small St., Kingston'),('V006','Robert Green','90 Straight St., Flatville'),('V007','Anna Berg','7 Quiet St., Blackfield'),('V008','Mary White','34 Park St., Redbush'),('V009','Gary Smith','65 Round St., Sandston'),('V010','George Jones','84 Main St., Darkwood'),('V011','Sara Brown','3 Short St., Stonefield'),('V012','Aaron Milstein','9 Bush St., Northville');
/*!40000 ALTER TABLE `visitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'bit604_rha'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19  9:16:19
