# SQL script to populate the BIT604_rha database tables.

INSERT INTO `bit604_rha`.`apartment_building`
(`BuildID`,`BuildName`,`Location`)
VALUES
('B001','Paradise Found','Rotorua'),
('B002','Serenity Place','Queenstown'),
('B003','Sunshine Oasis','Nelson'),
('B004','Beach View','Auckland'),
('B005','Heavens Gate','Dunedin'),
('B006','Lakeview Bliss','Taupo'),
('B007','Sunrise Resort','Christchurch'),
('B008','Harmony','Tauranga'),
('B009','Rising Star','Wellington');


INSERT INTO `bit604_rha`.`apartment`
(`AptNum`,`BuildID`,`Type`,`Bedrooms`,`Price`)
VALUES
(101,'B002','S',1,110),
(108,'B003','S',1,90),
(208,'B002','S',2,140),
(205,'B004','GA',1,105),
(103,'B001','S',1,90),
(109,'B004','GA',2,150),
(102,'B004','S',1,85),
(108,'B005','S',1,95),
(211,'B002','S',2,140),
(205,'B006','S',2,150),
(202,'B004','S',2,175),
(304,'B003','PH',2,185),
(105,'B007','S',1,110),
(307,'B008','PH',3,300),
(307,'B002','S',3,280),
(111,'B008','S',2,155),
(209,'B001','S',2,135),
(204,'B004','S',1,100),
(303,'B004','S',3,255),
(104,'B002','S',2,155),
(104,'B001','GA',2,175),
(301,'B004','PH',2,190),
(101,'B009','S',2,160),
(103,'B009','S',1,120),
(105,'B005','S',2,165),
(303,'B008','PH',3,320);


INSERT INTO `bit604_rha`.`visitor`
(`VisitorID`,`VisitorName`,`VisitorAddress`)
VALUES
('V001','Jane Bolcotte','3 Garden St., Greenville'),
('V002','Peter Bell','15 Long St., Blackston'),
('V003','Bao Wang','88 Wide St., Bankston'),
('V004','Evan Taylor','23 High St., Cleanville'),
('V005','Manaia Ariki','75 Small St., Kingston'),
('V006','Robert Green','90 Straight St., Flatville'),
('V007','Anna Berg','7 Quiet St., Blackfield'),
('V008','Mary White','34 Park St., Redbush'),
('V009','Gary Smith','65 Round St., Sandston'),
('V010','George Jones','84 Main St., Darkwood'),
('V011','Sara Brown','3 Short St., Stonefield'),
('V012','Aaron Milstein','9 Bush St., Northville');


INSERT INTO `bit604_rha`.`reservation`
(`ReservationID`,`BuildID`,`VisitorID`,`DateFrom`,`DateTo`,`AptNum`)
VALUES
('R001','B005','V002','2020-10-01','2020-10-06',108),
('R002','B004','V001','2020-09-25','2020-10-02',202),
('R003','B004','V004','2020-10-04','2020-10-12',301),
('R004','B002','V007','2020-09-17','2020-09-20',307),
('R005','B001','V003','2020-09-30','2020-10-04',104),
('R006','B006','V005','2020-10-10','2020-10-18',205),
('R007','B002','V008','2020-10-10','2020-10-20',104),
('R008','B004','V006','2020-10-21','2020-11-01',205),
('R009','B001','V010','2020-10-23','2020-10-29',209),
('R010','B003','V009','2020-10-24','2020-11-03',108),
('R011','B009','V003','2020-10-29','2020-11-05',101),
('R012','B009','V001','2020-11-06','2020-11-13',103),
('R013','B004','V007','2020-10-03','2020-10-10',303),
('R014','B007','V011','2020-10-31','2020-11-06',105),
('R015','B008','V012','2020-11-08','2020-11-15',307);


